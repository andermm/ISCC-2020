void MergeSort(long lVetor[], unsigned long ulSize);
