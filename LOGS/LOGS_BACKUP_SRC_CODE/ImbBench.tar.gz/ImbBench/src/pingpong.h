void pingpong(int numloops, int rank, int size);
void ipingpong(int numloops, int rank, int size);