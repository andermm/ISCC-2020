int mem_sort_bench(int rank, int Pattern);
