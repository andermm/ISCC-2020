int cpu_rand_bench(int rank, int Pattern);
