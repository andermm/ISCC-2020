void matrix_bench(int type, int size);
void balanced(int type);
void twolevels(int type, int num, int den, int rank);
void fourlevels(int type,int rank);
void eightlevels(int type, int rank);
void linear(int type, int rank, int size);
void amdahl(int type, int rank);
void teste(int type,int rank);
